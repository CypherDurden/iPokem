//
//  iPokemTests.swift
//  iPokemTests
//
//  Created by Vitor Lopes on 31/07/25.
//

import Testing
@testable import iPokem

struct iPokemTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
