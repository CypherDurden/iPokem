//
//  iPokemApp.swift
//  iPokem
//
//  Created by Vitor Lopes on 31/07/25.
//

import SwiftUI

@main
struct iPokemApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
